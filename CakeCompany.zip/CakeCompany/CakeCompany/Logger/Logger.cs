﻿using System;
namespace CakeCompany.Logger
{
    public static class Logger
    {
        public static void Error(Exception exception)
        {
            //Logging logic here
        }

        public static void Error(string errorMessage)
        {
            //Logging logic here
        }

        public static void Error(Object obj)
        {
            //Logging logic here
        }
        public static void Information(string stringInformation)
        {
            //Logging logic here
        }
        public static void Warning(string stringWarning)
        {
            //Logging logic here
        }
    }
}

