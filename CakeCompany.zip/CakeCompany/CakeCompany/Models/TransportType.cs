﻿namespace CakeCompany.Models
{
    internal enum TransportType
    {
        Van,
        Truck,
        Ship
    }
}
