﻿namespace CakeCompany.Models.Transport;

internal class Truck : IDelivery
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}