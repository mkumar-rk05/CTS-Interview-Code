﻿
namespace CakeCompany.Models.Transport
{
    internal interface IDelivery
    {
        bool Deliver(List<Product> products);
    }
}  