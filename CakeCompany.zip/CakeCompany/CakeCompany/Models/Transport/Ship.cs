﻿namespace CakeCompany.Models.Transport;

internal class Ship : IDelivery
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}