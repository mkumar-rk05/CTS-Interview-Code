﻿namespace CakeCompany.Models.Transport;

internal class Van : IDelivery
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}