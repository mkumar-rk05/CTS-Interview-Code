﻿namespace CakeCompany.Models;

internal class PaymentIn
{
    public bool IsSuccessful { get; set; }
    public bool HasCreditLimit { get; set; }
}
