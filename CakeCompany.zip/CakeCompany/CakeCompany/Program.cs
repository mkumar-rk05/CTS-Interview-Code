﻿// See https://aka.ms/new-console-template for more information

using CakeCompany.Provider;

var shipmentProvider = new ShipmentProvider(new OrderRepository());
var status = shipmentProvider.GetShipment();

Console.WriteLine(String.Format("Shipment  : {0}", status?"Successfull":"Failed"));
Console.Read();
