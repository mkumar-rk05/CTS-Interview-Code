﻿
namespace CakeCompany.Provider;

internal class TransportProvider
{
    public IDelivery GetTransport(List<Product> products)
    {
        IDelivery deliveryType = null  ;

        try
        {   
            if (products.Sum(p => p.Quantity) < 1000)
            {
                deliveryType = new Van();
            }
            else if (products.Sum(p => p.Quantity) > 1000 && products.Sum(p => p.Quantity) < 5000)
            {
                deliveryType = new Truck();

            }
            else
                deliveryType = new Ship();
        }
        catch (Exception ex)
        {
            Logger.Logger.Error(ex);
        }
        return deliveryType;

    }
}
