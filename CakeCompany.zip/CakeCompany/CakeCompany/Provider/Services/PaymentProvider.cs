﻿namespace CakeCompany.Provider;

internal class PaymentProvider
{
    public PaymentIn Process(Order order)
    {
        PaymentIn paymentIn = new PaymentIn();
        try
        {  
            if (order.ClientName.Contains("Important"))
            { 
                paymentIn.HasCreditLimit = false;
                paymentIn.IsSuccessful = true;
                 
            }
            else
            { 
                paymentIn.HasCreditLimit = true;
                paymentIn.IsSuccessful = true;
            } 

        }
        catch (Exception ex)
        {
            Logger.Logger.Error(ex);
        }
        return paymentIn;
    }
}