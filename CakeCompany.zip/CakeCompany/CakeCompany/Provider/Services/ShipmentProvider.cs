﻿namespace CakeCompany.Provider;
internal class ShipmentProvider
{
    private IOrderRepository _orderRepository;
    private CakeProvider _cakeProvider { get; }
    private PaymentProvider _paymentProvider { get; }
    private TransportProvider _transportProvider { get; }
    public ShipmentProvider(IOrderRepository orderRepository)
    {
        _orderRepository = orderRepository;
        _cakeProvider = new CakeProvider();
        _paymentProvider = new PaymentProvider();        
        _transportProvider = new TransportProvider();
    }
    public bool GetShipment() 
    {
        var status = false;
        try
        { 
            var latestOrders = _orderRepository.GetLatestOrders();

            if (!latestOrders.Any())
                return false;

            var bakedProducts = latestOrders
                 .Where(CanDeliverInTime)
                 .Where(IsPaymentValid)
                 .Select(order => _cakeProvider.Bake(order))
                 .ToList();

            var transportDelivery = _transportProvider.GetTransport(bakedProducts);
            status = transportDelivery.Deliver(bakedProducts);
            if (status)
                _orderRepository.UpdateOrders(latestOrders);
        }
        catch (Exception ex)
        {
            Logger.Logger.Error(ex);
        }
        return status;

    }

    private bool CanDeliverInTime(Order order) => _cakeProvider.Check(order) < order.EstimatedDeliveryTime;
    private bool IsPaymentValid(Order order) => _paymentProvider.Process(order).IsSuccessful;

  
}