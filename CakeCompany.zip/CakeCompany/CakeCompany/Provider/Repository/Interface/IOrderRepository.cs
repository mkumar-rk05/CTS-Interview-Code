﻿
namespace CakeCompany.Provider;

    public interface IOrderRepository
    {
        public Order[] GetLatestOrders();
        public void UpdateOrders(Order[] orders);
    }
