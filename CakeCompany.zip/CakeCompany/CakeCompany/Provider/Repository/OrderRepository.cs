﻿

namespace CakeCompany.Provider;

internal class OrderRepository : IOrderRepository
{
    public Order[] GetLatestOrders()
    {
        return new Order[]
        {
            new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25),
            new("ImportantCakeShop", DateTime.Now, 1, Cake.RedVelvet, 120.25)
        };
    }

    public void UpdateOrders(Order[] orders)
    {

        // Implement logic to Update Order status
    }
}


