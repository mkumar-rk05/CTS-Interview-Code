﻿

namespace CakeCompany.Provider;

internal class StubOrderRepository : IOrderRepository
{
    public Order[] GetLatestOrders()
    {
        return new Order[]
        {
            new("CakeBox-Stub", DateTime.Now, 1, Cake.RedVelvet, 120.25),
            new("ImportantCakeShop-Stub", DateTime.Now, 1, Cake.RedVelvet, 120.25)
        };
    }

    public void UpdateOrders(Order[] orders)
    {

    }
}


