using CakeCompany.Provider;

using Xunit;

namespace CakeCompany.UnitTest
{
    public class CakeCompanyTest
    {
        private ShipmentProvider _provider = new ShipmentProvider(new StubOrderRepository());
      
        [Fact]
        public void SuccessfullShipment()
        {
            var response = _provider.GetShipment();
            Assert.True(response);
        }

    }
}